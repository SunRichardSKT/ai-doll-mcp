# AI 共感娃娃代码 · Bridge v2.4.0 / 固件 v2.2.0

ESP32-C3 SuperMini + 74HC4051。保留现有八路压力接口，支持最多 16 个可配置逻辑通道；预设压力、NTC 温度输入和震动输出。本机 STDIO MCP 提供 27 个工具，开发板 HTTP MCP 提供 16 个工具。电脑桥接服务增加会话绑定事件、可靠投递、SSE 接入与 MCP Events 适配。

- 日常操作：[使用指南](docs/USER_GUIDE.md)。
- 通道配置与扩展接线：[多传感器指南](docs/SENSOR_CHANNELS.md)。
- 用户自选 AI 接入：[AI 安装文档](docs/AI_INSTALL.md)。
- 无需电脑 USB 数据连接：[Wi-Fi 无线采集](docs/WIFI_CONNECTION.md)。设备独立供电，电脑服务通过局域网保存历史。
- 新建普通聊天与远程连接：[Chat 窗口 MCP 接入指南](docs/CHAT_MCP.md)。GitHub 仓库地址不能代替 MCP 服务地址。
- 主动反馈与统一安装：[事件桥接指南](docs/PROACTIVE_INTERACTION.md)。运行 `tools/install_bridge.ps1`，或使用原入口启动服务。
- 编译目标：`firmware/platformio.ini` 中的 `supermini-lab`。
- 当前源码仅在 `firmware/src/`；已测试镜像和烧录地址见 [固件说明](firmware/prebuilt/README.md)。
- 电脑端入口：`tools/start_companion.ps1 -Port COM3`；MCP 配置生成：`python tools/install_companion_mcp.py`。
- 依赖：Python 3.12，`python -m pip install -r requirements-companion.txt`；编译另需 PlatformIO。
- 本包不包含 Wi-Fi 配置、访问令牌、个人历史或本机依赖。运行数据会在本机 `build/device-lab/` 创建。

默认关闭真实输入和真实输出。真实 ADC 需在传感器电路接好后启用；震动电机需外置驱动电路并单独确认启用，不能直接接 GPIO 或 4051。现有 PCB 没有增加物理端口。电脑长期历史支持 Wi-Fi 或 USB 采集，服务需保持运行。普通模式安静归档；主动反馈需要订阅，并由支持事件的宿主或用户 API 应用调用模型。演示页只生成明确标记的测试回执，未选择任何模型或部署公网服务。

每个文件的 SHA-256 见 `MANIFEST.json`。解压后可运行 `python tools/test_companion.py` 检查归档逻辑；设备测试会产生明确标记的模拟记录，使用前请读安装文档。
