# AI 共感娃娃代码 · Bridge v2.9.0 / 固件 v2.5.0

ESP32-C3 SuperMini + 74HC4051。保留现有八路压力接口，支持最多 16 个可配置逻辑通道；预设压力、NTC 温度输入和震动输出。本机 STDIO MCP 提供 44 个工具，开发板 HTTP MCP 提供 25 个工具。电脑桥接服务增加会话绑定事件、可靠投递、SSE 接入与 MCP Events 适配。

- 日常操作：[使用指南](docs/USER_GUIDE.md)。
- 历史导出、预览删除、保留期限和全范围统计：[历史管理指南](docs/HISTORY_MANAGEMENT.md)。
- 256 条设备缓存、重启补传与时间质量：[离线记录指南](docs/OFFLINE_RECORDS.md)。
- 压力校准、启动恢复及曲线：[校准指南](docs/CALIBRATION_AND_DAILY_MODE.md)。
- 动作摘要、安静时段和安装自检：[互动优化指南](docs/INTERACTION_OBSERVATIONS.md)。
- 通道配置与扩展接线：[多传感器指南](docs/SENSOR_CHANNELS.md)。
- 用户自选 AI 接入：[AI 安装文档](docs/AI_INSTALL.md)。
- 已配对设备发现、IP 恢复及可选登录启动：[无线恢复指南](docs/WIRELESS_RECOVERY.md)。
- 无需电脑 USB 数据连接：[Wi-Fi 无线采集](docs/WIFI_CONNECTION.md)。设备独立供电，电脑服务通过局域网保存历史。
- 新建普通聊天与远程连接：[Chat 窗口 MCP 接入指南](docs/CHAT_MCP.md)。GitHub 仓库地址不能代替 MCP 服务地址。
- 主动反馈与统一安装：[事件桥接指南](docs/PROACTIVE_INTERACTION.md)。运行 `tools/install_bridge.ps1`，或使用原入口启动服务。
- 编译目标：`firmware/platformio.ini` 中的 `supermini-lab`。
- 当前源码仅在 `firmware/src/`；已测试镜像和烧录地址见 [固件说明](firmware/prebuilt/README.md)。
- 电脑端入口：`tools/start_companion.ps1 -Port COM3`；MCP 配置生成：`python tools/install_companion_mcp.py`。
- 依赖：Python 3.12，`python -m pip install -r requirements-companion.txt`；编译另需 PlatformIO。
- 本包不包含 Wi-Fi 配置、访问令牌、个人历史或本机依赖。运行数据会在本机 `build/device-lab/` 创建。

默认手动模式关闭真实输入。接线确认后可保存日常模式，重启恢复输入；输出始终不恢复。真实 ADC 需在传感器电路接好后启用；震动电机需外置驱动电路并单独确认启用，不能直接接 GPIO 或 4051。现有 PCB 没有增加物理端口。电脑长期历史支持 Wi-Fi 或 USB 采集。服务离线时设备最多缓存 256 条事件；恢复后自动补传，未知时间不归入今天，旧事件不重发输出。普通模式安静归档；主动反馈需要订阅，并由支持事件的宿主或用户 API 应用调用模型。演示页只生成明确标记的测试回执，未选择任何模型或部署公网服务。

每个文件的 SHA-256 见 `MANIFEST.json`。解压后可运行 `python tools/test_companion.py` 检查归档逻辑；设备测试会产生明确标记的模拟记录，使用前请读安装文档。
