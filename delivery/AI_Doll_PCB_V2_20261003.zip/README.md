# AI_Doll_V2 PCB 交付

## 打开工程和准备元器件

1. 在嘉立创 EDA 专业版导入 `hardware/rev-v2/AI_Doll_V2_标准化完成_20261003.epro2`，包含原理图和 PCB。
2. 按同目录的标准化采购 BOM 购买板上器件；SuperMini、FSR、电池与板外充放电模块单独准备。
3. 焊接前读 [器件与电源核对](hardware/rev-v2/元器件标准化核对记录.md)和 [已下单焊位](hardware/rev-v2/ordered-gerber-20260920/已下单PCB封装核对.md)。

## 板子与装配

两层 **34.29 × 44.45mm**，SuperMini 模块、74HC4051 SOIC-16、八路外置 FSR。阻容以 0805 为主，C13 / C14 为 1206。J9 1=GND、2=外部5V；主板不含充电、升压或 BMS。

45 个采购器件已核对立创编号，SuperMini 自行采购，5 个裸铜测试点不采购插针。SW1 额定电流需向卖家确认。

## 验证边界

原生 PCB DRC 为 0；原理图无 error / fatal，仍有 2 个聚合 warn。标准化不改变板框、铜图形、焊盘或丝印镜像，无需只因料号更新重新下单裸板。

`ordered-gerber-20260920/` 是原已下单文件，不是新导出的生产文件。`verification/` 保留回读、几何和 DRC 证据。原生导出结构已核验，未在另一工程重新导入或完成实物组装验收。

逐文件校验见 `MANIFEST.json`。软件另从 [公开交付目录](https://github.com/SunRichardSKT/ai-doll-mcp/tree/main/delivery)下载。
