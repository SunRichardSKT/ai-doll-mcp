# AI Doll Linux 服务包

上传并解压此包，在服务器运行：

```bash
sudo bash Install_Server.sh --domain doll.your-domain.com
```

安装入口自动准备 Docker、配置、持久卷与 HTTPS。详情见 [远程部署指南](docs/REMOTE_SERVER_SETUP.md)。
无需上传 Windows Python；不包含个人配置或互动历史。
