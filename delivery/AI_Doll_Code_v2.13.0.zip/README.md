# AI 共感娃娃代码交付

固件 2.7.0 / 电脑 Bridge 2.13.0。ESP32-C3 SuperMini + 74HC4051，保留八路模拟接口和最多 16 个逻辑通道。电脑 MCP 45 个工具，设备 MCP 26 个工具；HTTP status/history/interaction 分别为 2/9/13 个工具。

先读 [安装指南](docs/AI_INSTALL.md)，完成配网、电脑服务、无线配对和客户端 MCP 导入。日常操作见 [使用指南](docs/USER_GUIDE.md)，FSR402 校准和手动阈值见 [校准指南](docs/CALIBRATION_AND_DAILY_MODE.md)。

- [文档导航](docs/README.md)、[接入现有对话](docs/EXISTING_CHAT.md)
- [Operit / OpenClaw / 自定义前端](docs/HOST_INTEGRATIONS.md)：兼容评估、包模板与事件转发脚本（未做真实平台验收）
- [完整 MCP 工具目录](docs/MCP_TOOLS.md)
- [通道与接线](docs/SENSOR_CHANNELS.md)、[DS18B20 数字温度](docs/DIGITAL_TEMPERATURE.md)
- [主动互动与 API 接入](docs/PROACTIVE_INTERACTION.md)、[聊天窗口](docs/CHAT_MCP.md)、[Secure 隧道安装与启动](docs/SECURE_MCP.md)、[Sakura 私密地址操作](docs/REMOTE_MCP.md)、[MCP 分阶段验收](docs/MCP_ACCEPTANCE_2_13.md)
- [无线采集](docs/WIFI_CONNECTION.md)、[地址恢复与登录启动](docs/WIRELESS_RECOVERY.md)
- [反馈偏好与自检](docs/INTERACTION_OBSERVATIONS.md)
- [离线缓存](docs/OFFLINE_RECORDS.md)、[历史管理](docs/HISTORY_MANAGEMENT.md)
- [无线升级](docs/OTA_UPDATE.md)、[烧录镜像](firmware/prebuilt/README.md)
- [实际验收范围](docs/DEVICE_LAB_TEST_REPORT.md)、[剩余工作](docs/DEVELOPMENT_PLAN.md)

本机客户端在项目根目录运行 tools/install_bridge.ps1；普通 Chat 推荐双击 tools/Install_Secure_MCP.cmd，首次配置后双击 tools/Start_Secure_MCP.cmd。Secure 另需 Platform 隧道与运行密钥，已通过普通 Chat 状态、历史及 60 秒模拟反馈。Sakura 入口保留，但普通 Chat 添加仍未通过。首次安装需要 Python 3.12 和依赖，详见安装指南；无需交付者本机依赖。源码在 firmware/src，编译目标为 supermini-lab。

未接传感器保持模拟/手动模式。真实震动需要板外驱动，不能直接接 GPIO 或 4051。普通触摸只记录，用户开始互动后才投递新事件；自建应用接入用户选择的模型回调，官方客户端的后台唤醒取决于其实际事件能力。

原创代码和文档按 MIT License 开源，见 LICENSE；第三方依赖和资料保留各自许可。此包不含 Wi-Fi、令牌、个人日志或历史版本。运行数据在本机 build/device-lab 创建。MANIFEST.json 包含每个文件的 SHA-256。真实传感器、用户模型和写 Flash 时物理断电仍需验收。
